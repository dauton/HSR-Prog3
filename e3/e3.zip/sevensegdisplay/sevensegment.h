#ifndef SEVENSEGMENT_H_
#define SEVENSEGMENT_H_

#include <iosfwd>

void printLargeDigits(int result, std::ostream &out);
void printError(std::ostream &out);

#endif
