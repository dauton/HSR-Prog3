#ifndef CALC_H_
#define CALC_H_
#include <iosfwd>

int calc(int number1, int number2, char calcOperator);
int calc(std::istream &input);

#endif
