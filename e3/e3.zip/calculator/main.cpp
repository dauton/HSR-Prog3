#include "pocketcalculator.h"

#include <iostream>

int main() {
	runPocketCalculator(std::cin, std::cout);
}
