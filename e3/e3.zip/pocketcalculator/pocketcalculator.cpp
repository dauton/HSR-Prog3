#include "pocketcalculator.h"
#include "sevensegment.h"
#include "calc.h"

#include <iostream>
#include <stdexcept>
#include <sstream>

void runPocketCalculator(std::istream &cin, std::ostream &cout) {
	cout << cin << "\n";
	/*while (cin) {
		try {
			int result = calc(cin);
			//istringstream in (to_string(calc(cin)));
			printLargeDigits(result, cout);
		} catch (...) {
			printError(cout);
			//cout << "ERROR";
			cin.clear();
			string line{};
			getline(cin, line);
		}
	}*/
}
